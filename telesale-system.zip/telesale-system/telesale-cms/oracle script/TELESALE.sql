/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : TELESALE ORC
Source Server Version : 110200
Source Host           : 10.10.1.146:9091
Source Schema         : TELESALE

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2017-02-20 17:41:21
*/


-- ----------------------------
-- Table structure for ACCOUNTS
-- ----------------------------
DROP TABLE "ACCOUNTS";
CREATE TABLE "ACCOUNTS" (
"ID" NUMBER(20) NOT NULL ,
"ACCOUNT_TYPE_CODE" VARCHAR2(45 BYTE) NOT NULL ,
"ACCOUNT_NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"DATE_OPENED" DATE DEFAULT NULL  NULL ,
"DATE_CLOSED" DATE DEFAULT NULL  NULL ,
"CURRENT_BALANCE" NUMBER(20) DEFAULT '0'  NULL ,
"AVAIL_BALANCE" NUMBER(20) DEFAULT '0'  NULL ,
"STATUS" NUMBER(20) DEFAULT '1'  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of ACCOUNTS
-- ----------------------------
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('270', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:12:19', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('271', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:12:41', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('280', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:15:53', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('290', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:16:52', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('291', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:23:26', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('292', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:25:54', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('293', 'AGENCY', 'telesale', TO_DATE('2017-02-20 17:27:13', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');
INSERT INTO "ACCOUNTS"(ID, ACCOUNT_TYPE_CODE, ACCOUNT_NAME, DATE_OPENED, DATE_CLOSED, CURRENT_BALANCE, AVAIL_BALANCE, STATUS) VALUES ('1', 'SYSTEM', 'Mysubscriber', TO_DATE('2016-12-28 19:08:37', 'YYYY-MM-DD HH24:MI:SS'), null, '0', '0', '1');

-- ----------------------------
-- Table structure for BILLS_LOG
-- ----------------------------
DROP TABLE "BILLS_LOG";
CREATE TABLE "BILLS_LOG" (
"ID" NUMBER(20) NOT NULL ,
"CODE" VARCHAR2(45 BYTE) DEFAULT NULL  NULL ,
"CONTENT" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"AMOUNT" NUMBER(20) DEFAULT NULL  NULL ,
"URL" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"CREATED_BY" NUMBER(20) DEFAULT NULL  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"CREATED_DATE" DATE DEFAULT NULL  NULL ,
"STATUS" NUMBER(11) DEFAULT '0'  NULL ,
"REVIEW_BY" NUMBER(20) DEFAULT NULL  NULL ,
"DISCOUNT" NUMBER(20) DEFAULT '0'  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of BILLS_LOG
-- ----------------------------
INSERT INTO "BILLS_LOG"(ID, CODE,CONTENT,AMOUNT,URL,CREATED_BY,CREATED_TIME,CREATED_DATE,STATUS,REVIEW_BY) VALUES ('1', '112', '112', '2000', '111', '1', TO_DATE('2017-02-20 12:23:59', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-02-06 12:24:05', 'YYYY-MM-DD HH24:MI:SS'), '1', '1', '5');

-- ----------------------------
-- Table structure for BLACK_LIST
-- ----------------------------
DROP TABLE "BLACK_LIST";
CREATE TABLE "BLACK_LIST" (
"ID" NUMBER(20) NOT NULL ,
"CUST_ID" NUMBER(20) DEFAULT NULL  NULL ,
"VTE_ID" NUMBER(20) DEFAULT NULL  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"CREATED_BY" VARCHAR2(200 BYTE) DEFAULT NULL  NULL ,
"IS_GLOBAL" NUMBER(11) DEFAULT '0'  NULL ,
"PARTNER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"MSISDN" VARCHAR2(45 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of BLACK_LIST
-- ----------------------------

-- ----------------------------
-- Table structure for BUSINESS_AREAS
-- ----------------------------
DROP TABLE "BUSINESS_AREAS";
CREATE TABLE "BUSINESS_AREAS" (
"ID" NUMBER(20) NOT NULL ,
"NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"CODE" VARCHAR2(45 BYTE) DEFAULT NULL  NULL ,
"URL_DATA" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"PARENT_ID" NUMBER(20) DEFAULT NULL  NULL ,
"DESCRIPTION" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"STATUS" NUMBER(1) DEFAULT NULL  NULL ,
"HAS_CHILDREN" NUMBER(1) DEFAULT 0  NULL ,
"HERARCHY_PATH" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of BUSINESS_AREAS
-- ----------------------------
INSERT INTO "BUSINESS_AREAS" VALUES ('310', 'Bất động sản', 'BDS', '[]', null, 'Bất động sản', '1', '0', '310');

-- ----------------------------
-- Table structure for CALL_HISTORIES
-- ----------------------------
DROP TABLE "CALL_HISTORIES";
CREATE TABLE "CALL_HISTORIES" (
"ID" NUMBER(20) NOT NULL ,
"USER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"PARTNER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"CUSTOMER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"BUSINESS_ID" NUMBER(20) DEFAULT NULL  NULL ,
"START_CALL" DATE DEFAULT NULL  NULL ,
"END_CALL" DATE DEFAULT NULL  NULL ,
"COUNT_TIME" NUMBER(11) DEFAULT 0  NULL ,
"FILE_PATH" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"CUSTOMER_STATUS" NUMBER(1) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of CALL_HISTORIES
-- ----------------------------

-- ----------------------------
-- Table structure for CUSTOMER
-- ----------------------------
DROP TABLE "CUSTOMER";
CREATE TABLE "CUSTOMER" (
"ID" NUMBER(20) NOT NULL ,
"FULL_NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"LAST_NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"FIRST_NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"MOBILE" VARCHAR2(15 BYTE) DEFAULT NULL  NULL ,
"EMAIL" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"STATUS" NUMBER(1) DEFAULT 1  NULL ,
"PROJECT" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"CALLER" NUMBER(20) DEFAULT NULL  NULL ,
"ADDRESS" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"WORK" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"DESCRIPTION" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"CALL_STATUS" NUMBER(1) DEFAULT 0  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"LAST_MODIFIED_TIME" DATE DEFAULT NULL  NULL ,
"HOBBIES" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"PARTNER_ID" NUMBER(20) DEFAULT 0  NULL ,
"TYPE" NUMBER(1) DEFAULT 0  NULL ,
"VTE_ID" NUMBER(20) DEFAULT 0  NULL ,
"COUNT_ACCESS" NUMBER(11) DEFAULT 0  NULL ,
"NOTE" VARCHAR2(500 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of CUSTOMER
-- ----------------------------
INSERT INTO "CUSTOMER" VALUES ('320', 'Pham Minh Thang', 'Minh Thang', 'Pham', '0194988156', 'a@a.com', '1', 'a@a.com', null, null, 'telesale', null, '0', TO_DATE('2017-02-20 17:40:52', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-02-20 17:40:52', 'YYYY-MM-DD HH24:MI:SS'), '310', '-1', '0', null, '0', null);

-- ----------------------------
-- Table structure for CUSTOMER_HOBBIES
-- ----------------------------
DROP TABLE "CUSTOMER_HOBBIES";
CREATE TABLE "CUSTOMER_HOBBIES" (
"ID" NUMBER(20) NOT NULL ,
"CUST_ID" NUMBER(20) NOT NULL ,
"HOBBY_ID" NUMBER(20) NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of CUSTOMER_HOBBIES
-- ----------------------------
INSERT INTO "CUSTOMER_HOBBIES" VALUES ('1', '320', '310');

-- ----------------------------
-- Table structure for PARTNER
-- ----------------------------
DROP TABLE "PARTNER";
CREATE TABLE "PARTNER" (
"ID" NUMBER(20) NOT NULL ,
"CODE" VARCHAR2(50 BYTE) NOT NULL ,
"NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"PHONE" VARCHAR2(15 BYTE) DEFAULT NULL  NULL ,
"MOBILE" VARCHAR2(15 BYTE) DEFAULT NULL  NULL ,
"FAX" VARCHAR2(15 BYTE) DEFAULT NULL  NULL ,
"WEBSITE" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"EMAIL" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"ADDRESS" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"LOGO" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"DESCRIPTION" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL ,
"PARENT_ID" NUMBER(20) DEFAULT NULL  NULL ,
"TYPE" VARCHAR2(255 BYTE) NOT NULL ,
"STATUS" NUMBER(1) DEFAULT 1  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"MODIFIED_TIME" DATE DEFAULT NULL  NULL ,
"CREATED_BY" NUMBER(20) DEFAULT NULL  NULL ,
"MODIFIED_BY" NUMBER(20) DEFAULT NULL  NULL ,
"HOBBIES" VARCHAR2(2000 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of PARTNER
-- ----------------------------
INSERT INTO "PARTNER"(id,code,name,phone,mobile,fax,website,email,address,logo,description,PARENT_ID,type,status,CREATED_TIME,modified_time,CREATED_BY,MODIFIED_BY,HOBBIES) VALUES ('303', 'Telesale', 'telesale', null, null, null, null, null, null, '/assets/img/user.png', null, '1', 'AGENCY', '1', TO_DATE('2017-02-20 17:27:13', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-02-20 17:27:13', 'YYYY-MM-DD HH24:MI:SS'), '1', null, null);
INSERT INTO "PARTNER"(id,code,name,phone,mobile,fax,website,email,address,logo,description,PARENT_ID,type,status,CREATED_TIME,modified_time,CREATED_BY,MODIFIED_BY,HOBBIES) VALUES ('1', 'Mysubscriber', 'Mysubscriber', null, null, null, null, 'telesalse@mysubscriber.vn', null, null, null, null, 'SYSTEM', '1', TO_DATE('2017-02-20 15:37:40', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-02-20 15:37:42', 'YYYY-MM-DD HH24:MI:SS'), null, null, null);

SELECT * FROM PARTNER;

-- ----------------------------
-- Table structure for PARTNER_ACCOUNT
-- ----------------------------
DROP TABLE "PARTNER_ACCOUNT";
CREATE TABLE "PARTNER_ACCOUNT" (
"ID" NUMBER(20) NOT NULL ,
"PARTNER_ID" NUMBER(20) NOT NULL ,
"ACCOUNT_ID" NUMBER(20) NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of PARTNER_ACCOUNT
-- ----------------------------
INSERT INTO "PARTNER_ACCOUNT" VALUES ('1', '1', '1');
INSERT INTO "PARTNER_ACCOUNT" VALUES ('2', '303', '293');

-- ----------------------------
-- Table structure for PARTNER_BUSINESS
-- ----------------------------
DROP TABLE "PARTNER_BUSINESS";
CREATE TABLE "PARTNER_BUSINESS" (
"ID" NUMBER(20) NOT NULL ,
"PARTNER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"BUSINESS_ID" NUMBER(20) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of PARTNER_BUSINESS
-- ----------------------------

-- ----------------------------
-- Table structure for ROLE
-- ----------------------------
DROP TABLE "ROLE";
CREATE TABLE "ROLE" (
"ID" NUMBER(20) NOT NULL ,
"NAME" VARCHAR2(255 BYTE) NOT NULL ,
"TYPE" VARCHAR2(255 BYTE) NOT NULL ,
"DESCRIPTION" VARCHAR2(500 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of ROLE
-- ----------------------------
INSERT INTO "ROLE" VALUES ('1', 'SYS_ADMIN', 'SYSTEM', 'SYSTEM ADMIN');
INSERT INTO "ROLE" VALUES ('2', 'AGE_ADMIN', 'AGENCY', 'AGENCY ADMIN');
INSERT INTO "ROLE" VALUES ('3', 'ORG_ADMIN', 'ORGANIZATION', 'ORGANIZATION ADMIN');
INSERT INTO "ROLE" VALUES ('4', 'ORG_TELESALE', 'ORGANIZATION', 'ORGANIZATION TELESALE');

-- ----------------------------
-- Table structure for SYS_PARAM
-- ----------------------------
DROP TABLE "SYS_PARAM";
CREATE TABLE "SYS_PARAM" (
"ID" NUMBER(20) NOT NULL ,
"KEY_" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"VALUE_" VARCHAR2(2000 BYTE) NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"MODIFIED_TIME" DATE DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of SYS_PARAM
-- ----------------------------

-- ----------------------------
-- Table structure for SYS_USER
-- ----------------------------
DROP TABLE "SYS_USER";
CREATE TABLE "SYS_USER" (
"ID" NUMBER(20) NOT NULL ,
"USER_NAME" VARCHAR2(255 BYTE) NOT NULL ,
"PASSWORD" VARCHAR2(255 BYTE) NOT NULL ,
"EMAIL" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"PHONE_NUMBER" VARCHAR2(15 BYTE) DEFAULT NULL  NULL ,
"FULL_NAME" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"ADDRESS" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"GENDER" NUMBER(1) DEFAULT '1'  NULL ,
"BIRTHDAY" DATE DEFAULT NULL  NULL ,
"AVATAR" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"PARTNER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"MODIFIED_TIME" DATE DEFAULT NULL  NULL ,
"CREATED_BY" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"MODIFIED_BY" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"STATUS" NUMBER(1) DEFAULT 1  NULL ,
"VERIFIED" NUMBER(1) DEFAULT 0  NULL ,
"VERIFIED_TIME" DATE DEFAULT NULL  NULL ,
"ALIAS_NUMBER" VARCHAR2(45 BYTE) DEFAULT NULL  NULL ,
"ALIAS_NAME" VARCHAR2(45 BYTE) DEFAULT NULL  NULL ,
"IS_TELESALER" NUMBER(1) DEFAULT 0  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of SYS_USER
-- ----------------------------
INSERT INTO "SYS_USER"(ID, USER_NAME,PASSWORD,EMAIL,PHONE_NUMBER,FULL_NAME,ADDRESS,GENDER,BIRTHDAY,AVATAR,PARTNER_ID,
CREATED_TIME,MODIFIED_TIME,CREATED_BY,MODIFIED_BY,STATUS,VERIFIED,VERIFIED_TIME,ALIAS_NUMBER,ALIAS_NAME,IS_TELESALER) VALUES ('9', 'age_admin', '$2a$10$B/pF50iQBEnBTCvCVyI1y.B126PVq1yOPZqdS67iDfpqeDyC3Lq0q', 'age_admin@telesale.vn', null, 'age_admin', null, '1', null, null, '1', TO_DATE('2017-02-20 16:59:11', 'YYYY-MM-DD HH24:MI:SS'), null, null, null, '1', '0', null, null, null, '0');
INSERT INTO "SYS_USER"(ID, USER_NAME,PASSWORD,EMAIL,PHONE_NUMBER,FULL_NAME,ADDRESS,GENDER,BIRTHDAY,AVATAR,PARTNER_ID,
CREATED_TIME,MODIFIED_TIME,CREATED_BY,MODIFIED_BY,STATUS,VERIFIED,VERIFIED_TIME,ALIAS_NUMBER,ALIAS_NAME,IS_TELESALER) VALUES ('10', 'org_admin', '$2a$10$Va0KyfjB4C91Tv5Eg8s8TeNuhT6FRcDe3rOZ8k9y/hrYh6X2U/3Ty', 'org_admin@telesale.vn', null, null, null, '1', null, null, '1', TO_DATE('2017-02-20 17:00:59', 'YYYY-MM-DD HH24:MI:SS'), null, null, null, '1', '0', null, null, null, '0');
INSERT INTO "SYS_USER"(ID, USER_NAME,PASSWORD,EMAIL,PHONE_NUMBER,FULL_NAME,ADDRESS,GENDER,BIRTHDAY,AVATAR,PARTNER_ID,
CREATED_TIME,MODIFIED_TIME,CREATED_BY,MODIFIED_BY,STATUS,VERIFIED,VERIFIED_TIME,ALIAS_NUMBER,ALIAS_NAME,IS_TELESALER) VALUES ('1', 'sys_admin', '$2a$10$nvD8d4dmQAxzL4ADoDKG4OJ7LTqq5UMLRaEr09z9rnCf808J9KP2i', 'sys_admin@telesale.vn', null, null, null, '1', null, null, '1', TO_DATE('2017-02-20 15:30:52', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2017-02-20 15:30:55', 'YYYY-MM-DD HH24:MI:SS'), null, null, '1', '0', null, null, null, '0');

-- ----------------------------
-- Table structure for TRANSACTION_EXT
-- ----------------------------
DROP TABLE "TRANSACTION_EXT";
CREATE TABLE "TRANSACTION_EXT" (
"ID" NUMBER(20) NOT NULL ,
"TRANS_ID" NUMBER(20) DEFAULT NULL  NULL ,
"TRANS_DATE" DATE DEFAULT NULL  NULL ,
"KEY_NAME" VARCHAR2(32 BYTE) DEFAULT NULL  NULL ,
"KEY_VALUE" VARCHAR2(512 BYTE) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of TRANSACTION_EXT
-- ----------------------------

-- ----------------------------
-- Table structure for TRANSACTIONS
-- ----------------------------
DROP TABLE "TRANSACTIONS";
CREATE TABLE "TRANSACTIONS" (
"ID" NUMBER(20) NOT NULL ,
"ACCOUNT_ID" NUMBER(20) DEFAULT NULL  NULL ,
"COUNTERPARTY_ID" NUMBER(20) DEFAULT NULL  NULL ,
"PAYMENT_METHOD_CODE" VARCHAR2(16 BYTE) DEFAULT NULL  NULL ,
"SERVICE_CODE" VARCHAR2(16 BYTE) DEFAULT NULL  NULL ,
"TRANS_STATUS" NUMBER(11) DEFAULT NULL  NULL ,
"TRANS_TYPE" NUMBER(11) DEFAULT NULL  NULL ,
"TRANS_DATE" DATE DEFAULT NULL  NULL ,
"TRANS_AMOUNT" NUMBER(20) DEFAULT NULL  NULL ,
"CHANNEL" NUMBER(11) DEFAULT 0  NULL ,
"TRANS_DESC" VARCHAR2(512 BYTE) DEFAULT NULL  NULL ,
"USER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"FROM_IP" VARCHAR2(64 BYTE) DEFAULT NULL  NULL ,
"DATA" VARCHAR2(2000 BYTE) NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of TRANSACTIONS
-- ----------------------------

-- ----------------------------
-- Table structure for USER_LOG
-- ----------------------------
DROP TABLE "USER_LOG";
CREATE TABLE "USER_LOG" (
"ID" NUMBER(20) NOT NULL ,
"USER_ID" NUMBER(20) NOT NULL ,
"USERNAME" VARCHAR2(255 BYTE) NOT NULL ,
"ACTION" VARCHAR2(255 BYTE) NOT NULL ,
"ACTION_TIME" DATE NOT NULL ,
"IP_ADDRESS" VARCHAR2(20 BYTE) NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of USER_LOG
-- ----------------------------
INSERT INTO "USER_LOG" VALUES ('11', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 15:54:00', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('13', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 16:06:33', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('14', '1', 'sys_admin', 'LOGOUT', TO_DATE('2017-02-20 16:10:00', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('15', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 16:10:10', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('21', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 16:40:00', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('230', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 16:40:47', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('25', '1', 'sys_admin', 'CREATE_USER', TO_DATE('2017-02-20 16:59:11', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('26', '1', 'sys_admin', 'CREATE_USER', TO_DATE('2017-02-20 17:00:59', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('18', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 16:31:13', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');
INSERT INTO "USER_LOG" VALUES ('12', '1', 'sys_admin', 'LOGIN', TO_DATE('2017-02-20 15:59:55', 'YYYY-MM-DD HH24:MI:SS'), '0:0:0:0:0:0:0:1');

-- ----------------------------
-- Table structure for USER_ROLE
-- ----------------------------
DROP TABLE "USER_ROLE";
CREATE TABLE "USER_ROLE" (
"ID" NUMBER(20) NOT NULL ,
"USER_ID" NUMBER(20) NOT NULL ,
"ROLE_ID" NUMBER(20) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of USER_ROLE
-- ----------------------------
INSERT INTO "USER_ROLE" VALUES ('1', '1', '1');
INSERT INTO "USER_ROLE" VALUES ('21', '224', '1');
INSERT INTO "USER_ROLE" VALUES ('22', '225', '1');

-- ----------------------------
-- Table structure for USER_VERIFY
-- ----------------------------
DROP TABLE "USER_VERIFY";
CREATE TABLE "USER_VERIFY" (
"ID" NUMBER(20) NOT NULL ,
"CODE" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"USER_ID" NUMBER(20) DEFAULT NULL  NULL ,
"EMAIL" VARCHAR2(255 BYTE) DEFAULT NULL  NULL ,
"TYPE" NUMBER(1) DEFAULT '0'  NULL ,
"CREATED_TIME" DATE DEFAULT NULL  NULL ,
"EXPIRED_TIME" DATE DEFAULT NULL  NULL ,
"STATUS" NUMBER(1) DEFAULT NULL  NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Records of USER_VERIFY
-- ----------------------------

-- ----------------------------
-- Sequence structure for ACCOUNT_PARTNER_SEQ
-- ----------------------------
DROP SEQUENCE "ACCOUNT_PARTNER_SEQ";
CREATE SEQUENCE "ACCOUNT_PARTNER_SEQ"
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9999999999999999999999999999
 START WITH 22
 CACHE 20;

-- ----------------------------
-- Sequence structure for CUSTOMER_HOBBIES_SEQ
-- ----------------------------
DROP SEQUENCE "CUSTOMER_HOBBIES_SEQ";
CREATE SEQUENCE "CUSTOMER_HOBBIES_SEQ"
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9999999999999999999999999999
 START WITH 21
 CACHE 20;

-- ----------------------------
-- Sequence structure for HIBERNATE_SEQUENCE
-- ----------------------------
DROP SEQUENCE "HIBERNATE_SEQUENCE";
CREATE SEQUENCE "HIBERNATE_SEQUENCE"
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9999999
 START WITH 41
 CACHE 20;

-- ----------------------------
-- Sequence structure for INCREMENT_SEQ
-- ----------------------------
DROP SEQUENCE "INCREMENT_SEQ";
CREATE SEQUENCE "INCREMENT_SEQ"
 INCREMENT BY 1
 MINVALUE 1
 MAXVALUE 9999999999999999999999999999
 START WITH 21
 CACHE 20;

-- ----------------------------
-- Sequence structure for USER_ROLE_SEQ
-- ----------------------------
DROP SEQUENCE "USER_ROLE_SEQ";
CREATE SEQUENCE "USER_ROLE_SEQ"
 INCREMENT BY 1
 MINVALUE 21
 MAXVALUE 9999999999999999999999999999
 START WITH 41
 CACHE 20;

-- ----------------------------
-- Indexes structure for table ACCOUNTS
-- ----------------------------

-- ----------------------------
-- Checks structure for table ACCOUNTS
-- ----------------------------
ALTER TABLE "ACCOUNTS" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "ACCOUNTS" ADD CHECK ("ACCOUNT_TYPE_CODE" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table ACCOUNTS
-- ----------------------------
ALTER TABLE "ACCOUNTS" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table BILLS_LOG
-- ----------------------------

-- ----------------------------
-- Checks structure for table BILLS_LOG
-- ----------------------------
ALTER TABLE "BILLS_LOG" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BILLS_LOG
-- ----------------------------
ALTER TABLE "BILLS_LOG" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table BLACK_LIST
-- ----------------------------

-- ----------------------------
-- Checks structure for table BLACK_LIST
-- ----------------------------
ALTER TABLE "BLACK_LIST" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLACK_LIST
-- ----------------------------
ALTER TABLE "BLACK_LIST" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table BUSINESS_AREAS
-- ----------------------------

-- ----------------------------
-- Checks structure for table BUSINESS_AREAS
-- ----------------------------
ALTER TABLE "BUSINESS_AREAS" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BUSINESS_AREAS
-- ----------------------------
ALTER TABLE "BUSINESS_AREAS" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table CALL_HISTORIES
-- ----------------------------

-- ----------------------------
-- Checks structure for table CALL_HISTORIES
-- ----------------------------
ALTER TABLE "CALL_HISTORIES" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table CALL_HISTORIES
-- ----------------------------
ALTER TABLE "CALL_HISTORIES" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table CUSTOMER
-- ----------------------------

-- ----------------------------
-- Checks structure for table CUSTOMER
-- ----------------------------
ALTER TABLE "CUSTOMER" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table CUSTOMER
-- ----------------------------
ALTER TABLE "CUSTOMER" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table CUSTOMER_HOBBIES
-- ----------------------------

-- ----------------------------
-- Triggers structure for table CUSTOMER_HOBBIES
-- ----------------------------
CREATE OR REPLACE TRIGGER "CUSTOMER_HOBBIES_TRIG" BEFORE INSERT ON "CUSTOMER_HOBBIES" REFERENCING OLD AS "OLD" NEW AS "NEW" FOR EACH ROW ENABLE
BEGIN
  SELECT customer_hobbies_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
-- ----------------------------
-- Uniques structure for table CUSTOMER_HOBBIES
-- ----------------------------
ALTER TABLE "CUSTOMER_HOBBIES" ADD UNIQUE ("CUST_ID", "HOBBY_ID");

-- ----------------------------
-- Checks structure for table CUSTOMER_HOBBIES
-- ----------------------------
ALTER TABLE "CUSTOMER_HOBBIES" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "CUSTOMER_HOBBIES" ADD CHECK ("CUST_ID" IS NOT NULL);
ALTER TABLE "CUSTOMER_HOBBIES" ADD CHECK ("HOBBY_ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table CUSTOMER_HOBBIES
-- ----------------------------
ALTER TABLE "CUSTOMER_HOBBIES" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table PARTNER
-- ----------------------------

-- ----------------------------
-- Uniques structure for table PARTNER
-- ----------------------------
ALTER TABLE "PARTNER" ADD UNIQUE ("CODE");

-- ----------------------------
-- Checks structure for table PARTNER
-- ----------------------------
ALTER TABLE "PARTNER" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "PARTNER" ADD CHECK ("CODE" IS NOT NULL);
ALTER TABLE "PARTNER" ADD CHECK ("TYPE" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table PARTNER
-- ----------------------------
ALTER TABLE "PARTNER" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table PARTNER_ACCOUNT
-- ----------------------------

-- ----------------------------
-- Triggers structure for table PARTNER_ACCOUNT
-- ----------------------------
CREATE OR REPLACE TRIGGER "ACCOUNT_PARTNER_TRIG" BEFORE INSERT ON "PARTNER_ACCOUNT" REFERENCING OLD AS "OLD" NEW AS "NEW" FOR EACH ROW ENABLE
BEGIN
  SELECT account_partner_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
-- ----------------------------
-- Uniques structure for table PARTNER_ACCOUNT
-- ----------------------------
ALTER TABLE "PARTNER_ACCOUNT" ADD UNIQUE ("PARTNER_ID", "ACCOUNT_ID");

-- ----------------------------
-- Checks structure for table PARTNER_ACCOUNT
-- ----------------------------
ALTER TABLE "PARTNER_ACCOUNT" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "PARTNER_ACCOUNT" ADD CHECK ("PARTNER_ID" IS NOT NULL);
ALTER TABLE "PARTNER_ACCOUNT" ADD CHECK ("ACCOUNT_ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table PARTNER_ACCOUNT
-- ----------------------------
ALTER TABLE "PARTNER_ACCOUNT" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table PARTNER_BUSINESS
-- ----------------------------

-- ----------------------------
-- Checks structure for table PARTNER_BUSINESS
-- ----------------------------
ALTER TABLE "PARTNER_BUSINESS" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table PARTNER_BUSINESS
-- ----------------------------
ALTER TABLE "PARTNER_BUSINESS" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table ROLE
-- ----------------------------

-- ----------------------------
-- Checks structure for table ROLE
-- ----------------------------
ALTER TABLE "ROLE" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "ROLE" ADD CHECK ("NAME" IS NOT NULL);
ALTER TABLE "ROLE" ADD CHECK ("TYPE" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table ROLE
-- ----------------------------
ALTER TABLE "ROLE" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table SYS_PARAM
-- ----------------------------

-- ----------------------------
-- Checks structure for table SYS_PARAM
-- ----------------------------
ALTER TABLE "SYS_PARAM" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table SYS_PARAM
-- ----------------------------
ALTER TABLE "SYS_PARAM" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table SYS_USER
-- ----------------------------

-- ----------------------------
-- Triggers structure for table SYS_USER
-- ----------------------------
CREATE OR REPLACE TRIGGER "INCREMENT_BIR" BEFORE INSERT ON "SYS_USER" REFERENCING OLD AS "OLD" NEW AS "NEW" FOR EACH ROW ENABLE
BEGIN
  SELECT increment_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
-- ----------------------------
-- Uniques structure for table SYS_USER
-- ----------------------------
ALTER TABLE "SYS_USER" ADD UNIQUE ("USER_NAME");

-- ----------------------------
-- Checks structure for table SYS_USER
-- ----------------------------
ALTER TABLE "SYS_USER" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "SYS_USER" ADD CHECK ("USER_NAME" IS NOT NULL);
ALTER TABLE "SYS_USER" ADD CHECK ("PASSWORD" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table SYS_USER
-- ----------------------------
ALTER TABLE "SYS_USER" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table TRANSACTION_EXT
-- ----------------------------

-- ----------------------------
-- Checks structure for table TRANSACTION_EXT
-- ----------------------------
ALTER TABLE "TRANSACTION_EXT" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table TRANSACTION_EXT
-- ----------------------------
ALTER TABLE "TRANSACTION_EXT" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table TRANSACTIONS
-- ----------------------------

-- ----------------------------
-- Checks structure for table TRANSACTIONS
-- ----------------------------
ALTER TABLE "TRANSACTIONS" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table TRANSACTIONS
-- ----------------------------
ALTER TABLE "TRANSACTIONS" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table USER_LOG
-- ----------------------------

-- ----------------------------
-- Checks structure for table USER_LOG
-- ----------------------------
ALTER TABLE "USER_LOG" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "USER_LOG" ADD CHECK ("USER_ID" IS NOT NULL);
ALTER TABLE "USER_LOG" ADD CHECK ("USERNAME" IS NOT NULL);
ALTER TABLE "USER_LOG" ADD CHECK ("ACTION" IS NOT NULL);
ALTER TABLE "USER_LOG" ADD CHECK ("ACTION_TIME" IS NOT NULL);
ALTER TABLE "USER_LOG" ADD CHECK ("IP_ADDRESS" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table USER_LOG
-- ----------------------------
ALTER TABLE "USER_LOG" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table USER_ROLE
-- ----------------------------

-- ----------------------------
-- Triggers structure for table USER_ROLE
-- ----------------------------
CREATE OR REPLACE TRIGGER "USER_ROLE_TRIGGER" BEFORE INSERT ON "USER_ROLE" REFERENCING OLD AS "OLD" NEW AS "NEW" FOR EACH ROW ENABLE
begin
     select user_role_seq.nextval into :new.id from dual;
   end;
-- ----------------------------
-- Checks structure for table USER_ROLE
-- ----------------------------
ALTER TABLE "USER_ROLE" ADD CHECK ("ID" IS NOT NULL);
ALTER TABLE "USER_ROLE" ADD CHECK ("USER_ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table USER_ROLE
-- ----------------------------
ALTER TABLE "USER_ROLE" ADD PRIMARY KEY ("ID");

-- ----------------------------
-- Indexes structure for table USER_VERIFY
-- ----------------------------

-- ----------------------------
-- Checks structure for table USER_VERIFY
-- ----------------------------
ALTER TABLE "USER_VERIFY" ADD CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table USER_VERIFY
-- ----------------------------
ALTER TABLE "USER_VERIFY" ADD PRIMARY KEY ("ID");
